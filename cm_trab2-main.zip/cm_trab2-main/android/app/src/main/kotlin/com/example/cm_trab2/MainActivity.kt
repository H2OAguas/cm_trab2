package com.example.cm_trab2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
