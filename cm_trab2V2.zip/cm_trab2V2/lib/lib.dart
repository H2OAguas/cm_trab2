library lib;

export 'dart:async';
export 'package:flutter/material.dart';
export 'package:gestao_futebol/main.dart';
export './widgets/jog_list_ctrl_dopp.dart';
// import './teste.dart';
export './widgets/app_bar.dart';
export 'objectbox.dart';
export '../teste.dart';
